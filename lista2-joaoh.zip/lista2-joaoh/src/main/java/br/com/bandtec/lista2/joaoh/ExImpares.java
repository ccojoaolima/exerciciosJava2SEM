package br.com.bandtec.lista2.joaoh;

/**
 *
 * @author Aluno
 */
public class ExImpares {
    public static void main(String[] args) {
        Integer numerosImpares = 0;
        
        for (int i = 0; i <= 90; i++) {
            if(i%2 != 0){
            numerosImpares++;
            System.out.println(i);
            
        }
         
            
    }
    }
}

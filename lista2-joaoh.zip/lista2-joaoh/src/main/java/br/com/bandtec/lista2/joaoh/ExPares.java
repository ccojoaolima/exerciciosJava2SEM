package br.com.bandtec.lista2.joaoh;

public class ExPares {
    public static void main(String[] args) {
        Integer i = 0;
        while (i <=40) {
            if(i % 2 == 0){
            System.out.println(i);
            }
            i++;
            
        }
    }
    
}
